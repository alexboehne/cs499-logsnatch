import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Thunderous Willing Turkey</title>
        <meta property="og:title" content="Thunderous Willing Turkey" />
        <link
          rel="canonical"
          href="https://thunderous-willing-turkey-zq65az.teleporthq.app/"
        />
      </Helmet>
      <img src="/logsnatch-logo-500w.png" alt="image" className="home-image" />
      <h1 className="home-text1">Welcome to LogSnatch</h1>
      <form
        data-form-id="5372ab93-8b51-44e0-b316-e58067cbb2c6"
        className="home-form"
      >
        <input
          type="text"
          placeholder="ssn"
          name="ssn"
          autoComplete="new-password"
          spellCheck="false"
          autoCapitalize="off"
          autoCorrect="off"
          tabIndex="-1"
          id="thq_ssn_gIW0"
          data-form-field-id="thq_ssn_gIW0"
          className="home-textinput1 input"
        />
        <div className="home-container2">
          <label htmlFor="thq_name_SXRP" className="home-text2">
            Username
          </label>
          <input
            type="text"
            placeholder="Username"
            id="thq_name_SXRP"
            name="username"
            data-form-field-id="thq_name_SXRP"
            className="home-textinput2 input"
          />
        </div>
        <div className="home-container3">
          <label htmlFor="thq_email_ktrI" className="home-text3">
            Password
          </label>
          <input
            type="email"
            placeholder="Password"
            id="thq_email_ktrI"
            name="password"
            data-form-field-id="thq_email_ktrI"
            className="home-textinput3 input"
          />
        </div>
        <button
          type="submit"
          id="thq_button_gU3U"
          name="button"
          data-form-field-id="thq_button_gU3U"
          className="home-button1 button"
        >
          Login
        </button>
        <button
          type="button"
          id="thq_button_X3Z5"
          name="button"
          data-form-field-id="thq_button_X3Z5"
          className="button"
        >
          Create Account
        </button>
      </form>
      <a href="https://play.teleporthq.io/signup" className="home-link">
        <div aria-label="Sign up to TeleportHQ" className="home-container4">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="home-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="home-text4">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Home
